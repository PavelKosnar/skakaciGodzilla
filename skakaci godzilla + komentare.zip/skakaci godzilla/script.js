const dinosaurus = document.getElementById('dinosaurus');
const mrakodrapy = document.getElementById('mrakodrapy');
const skore = document.getElementById('skore');
/*vytvorim si 3 konstanty, ktere budou zastavat jednotlive divy*/


function skok() {
    dinosaurus.classList.add('animace-skoku');
    setTimeout(() => {
        dinosaurus.classList.remove('animace-skoku');
    }, 700);
    /*animaci skoku, kterou jsem uz vytvoril, priradim divu dinosaurus a nastavim, ze jde pouzit jen kazdych 0.7 sekund*/
}

document.addEventListener('keypress', () => {
    if (!dinosaurus.classList.contains('animace-skoku')){
    skok();
    }
    /*animace skoku se spusti pouze pri stisknuti libovolne klavesy*/
});

setInterval(() => {

    let hodnoceniSkore = 0;

    if (skore.innerText > 5000) {
        hodnoceniSkore = 2;
    } else if (skore.innerText > 1000) {
        hodnoceniSkore = 1;
    }
    /*vytvorim si promennou hodnoceniSkore, pomoci ktere budu hodnotit dovednosti hrace*/

    const dinosaurusTop = parseInt(window.getComputedStyle(dinosaurus).getPropertyValue('top'));
    const mrakodrapyLeft = parseInt(window.getComputedStyle(mrakodrapy).getPropertyValue('left'));

    if (mrakodrapyLeft < 0) {
        mrakodrapy.style.display = 'none';
    } else {
        mrakodrapy.style.display = '';
    }
    /*jakmile leva strana divu mrakodrapy opusti oblast divu game, tak zmizi a objevi se az bude zase na zacatku sve animace*/

    if (mrakodrapyLeft < 100 && mrakodrapyLeft > 0 && dinosaurusTop > 465 && hodnoceniSkore == 0) {
        alert("Moc ti to nejde :)" + "\n\nMáš skóre: " + skore.innerText + "\n\nChceš hrát znovu?");
        location.reload();
    } else if (mrakodrapyLeft < 150 && mrakodrapyLeft > 0 && dinosaurusTop > 465 && hodnoceniSkore == 1){
        alert("Jde ti to dobře, mohl bys to dělat profesionálně\n\nMáš skóre: " + skore.innerText + "\n\nChceš hrát znovu?");
        location.reload();
    } else if (mrakodrapyLeft < 150 && mrakodrapyLeft > 0 && dinosaurusTop > 465 && hodnoceniSkore == 2){
        alert("Překonal jsi mé největší skóre, gratuluji, právě nemáš život :)\n\nMáš skóre: " + skore.innerText + "\n\nChceš hrát znovu?");
        location.reload();
    }
    skore.innerText++;
    /*pokud se mrakodrapy srazi s dinosaurem, hra se ukonci*/
    /*pomoci alertu se vypise skore a me slovni hodnoceni na zaklade hodnoty hodnoceniSkore*/
    /*pokud se vsak mrakodrapy nesrazi s dinosaurem, hra bude pokracovat a zvysi se skore*/

}, 50);

