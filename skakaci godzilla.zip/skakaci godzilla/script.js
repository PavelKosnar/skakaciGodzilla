const dinosaurus = document.getElementById('dinosaurus');
const mrakodrapy = document.getElementById('mrakodrapy');
const skore = document.getElementById('skore');


function skok() {
    dinosaurus.classList.add('animace-skoku');
    setTimeout(() => {
        dinosaurus.classList.remove('animace-skoku');
    }, 500);
}

document.addEventListener('keypress', () => {
    if (!dinosaurus.classList.contains('animace-skoku')){
    skok();
    }
});

setInterval(() => {

    let hodnoceniSkore = 0;

    if (skore.innerText > 5000) {
        hodnoceniSkore = 2;
    } else if (skore.innerText > 1000) {
        hodnoceniSkore = 1;
    }

    const dinosaurusTop = parseInt(window.getComputedStyle(dinosaurus).getPropertyValue('top'));
    const mrakodrapyLeft = parseInt(window.getComputedStyle(mrakodrapy).getPropertyValue('left'));

    if (mrakodrapyLeft < 0) {
        mrakodrapy.style.display = 'none';
    } else {
        mrakodrapy.style.display = '';
    }

    if (mrakodrapyLeft < 100 && mrakodrapyLeft > 0 && dinosaurusTop > 465 && hodnoceniSkore == 0) {
        alert("Moc ti to nejde :)" + "\n\nMáš skóre: " + skore.innerText + "\n\nChceš hrát znovu?");
        location.reload();
    } else if (mrakodrapyLeft < 150 && mrakodrapyLeft > 0 && dinosaurusTop > 465 && hodnoceniSkore == 1){
        alert("Jde ti to dobře, mohl bys to dělat profesionálně\n\nMáš skóre: " + skore.innerText + "\n\nChceš hrát znovu?");
        location.reload();
    } else if (mrakodrapyLeft < 150 && mrakodrapyLeft > 0 && dinosaurusTop > 465 && hodnoceniSkore == 2){
        alert("Překonal jsi mé největší skóre, gratuluji, právě nemáš život :)\n\nMáš skóre: " + skore.innerText + "\n\nChceš hrát znovu?");
        location.reload();
    }
    skore.innerText++;

}, 50);

